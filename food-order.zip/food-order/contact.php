<?php include('partials-front/menu.php'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Contacts</title>
    <link rel="stylesheet" href="css/style.css">
    </head>

<body>
<section class="contact">
        <div class="container">
            <h2 class="text-center">Team G3H</h2>
              
                        
                            <div style="width: 19%; float: left; margin: 2%;">
                            <img src="http://localhost/food-order/images/contact/gokul.jpeg" alt="Gokul" class="img-responsive img-curve">
                                                                        

                                <h3 style="position: relative; bottom: 45px; left: 15%; color: white; -webkit-text-fill-color: white; -webkit-text-stroke-width: 1px; -webkit-text-stroke-color: black;" >Gokul G Rao</h3>
                            </div>
                          
                       
                            <div style="width: 19%; float: left; margin: 2%;">
                            <img src="http://localhost/food-order/images/contact/govind.png" alt="Govind" class="img-responsive img-curve">
                                                                        

                                <h3 style="position: relative; bottom: 45px; left: 27%; color: white; -webkit-text-fill-color: white; -webkit-text-stroke-width: 1px; -webkit-text-stroke-color: black;" >Govind</h3>
                            </div>
                        

                            <div style="width: 19%; float: left; margin: 2%;">
                            <img src="http://localhost/food-order/images/contact/gwatsin.png" alt="Gwatsin" class="img-responsive img-curve">
                                                                        

                                <h3 style="position: relative; bottom: 45px; left: 5%; color: white; -webkit-text-fill-color: white; -webkit-text-stroke-width: 1px; -webkit-text-stroke-color: black;" >Gwatsin Thong</h3>
                            </div>


                            <div style="width: 19%; float: left; margin: 2%;">
                            <img src="http://localhost/food-order/images/contact/harsh.jpeg" alt="Harsh" class="img-responsive img-curve">
                                                                        

                                <h3 style="position: relative; bottom: 45px; left: 3%; color: white; -webkit-text-fill-color: white; -webkit-text-stroke-width: 1px; -webkit-text-stroke-color: black;" >Harsh Maganur</h3>
                            </div>
                  

            <div class="clearfix"></div>
        </div>
    </section>
    </body>
</html>

<?php include('partials-front/footer.php'); ?>